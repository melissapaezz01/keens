package mx.itson.keens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AgregarWinnerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_winner)

    }
}